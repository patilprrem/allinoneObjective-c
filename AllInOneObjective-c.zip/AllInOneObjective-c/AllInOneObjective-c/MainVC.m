//
//  MainVC.m
//  AllInOneObjective-c
//
//  Created by GadgetZone on 02/03/17.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import "MainVC.h"
#import "ViewController.h"
@interface MainVC ()
{
    NSArray *arrTblData;
}
@end

@implementation MainVC

- (void)viewDidLoad {
    [super viewDidLoad];
    arrTblData =[[NSArray alloc]initWithObjects:@"TableDemo",@"SliderImage&JsonModel",@"AfNetworking Demo",@"Collection Demo", nil];
    self.navigationController.navigationBarHidden=NO;
    self.navigationItem.title=@"All In One Demo";
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrTblData.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.textLabel.text=[arrTblData objectAtIndex:indexPath.row];
    cell.selectionStyle=UITableViewCellSelectionStyleBlue;
    UIImageView *imgView=[[UIImageView alloc]initWithFrame:CGRectMake(self.view.frame.size.width-50, 10, 23, 23)];
    imgView.image=[UIImage imageNamed:@"arrowRight.png"];
    [cell.contentView addSubview:imgView];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIViewController *vc;
    if (indexPath.row==0) {
        vc=[self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    }
    else if (indexPath.row==1)
    {
        vc=[self.storyboard instantiateViewControllerWithIdentifier:@"ImageSlideVc"];
    }
    else if (indexPath.row==2)
    {
        vc=[self.storyboard instantiateViewControllerWithIdentifier:@"AfNetworkingVc"];
    }
    else if (indexPath.row==3)
    {
        vc=[self.storyboard instantiateViewControllerWithIdentifier:@"CollectionVc"];
    }
    [self.navigationController pushViewController:vc animated:YES];
}

@end
