//
//  ViewController.h
//  AllInOneObjective-c
//
//  Created by GadgetZone on 28/02/17.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"
#import "MBProgressHUD.h"
@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate>
{
    NSMutableDictionary *responseStoreDetails;
    NSMutableDictionary *responseDeleteSales;
    NSMutableDictionary *responseDeletePayment;
    NSMutableDictionary *responseMultiDelete;
    
    IBOutlet UILabel *lblStore;
    IBOutlet UILabel *lblDate;
    
    IBOutlet UITableView *tblViewMain;
}

@property (nonatomic,strong)NSString *strId;
@property (nonatomic,strong)NSString *strName;
@property (nonatomic,strong)NSString *strDate;


@end

