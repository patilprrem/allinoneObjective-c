//
//  ViewController.m
//  AllInOneObjective-c
//
//  Created by GadgetZone on 28/02/17.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import "ViewController.h"
#import "tblcell.h"
@interface ViewController ()
{
    NSMutableArray *dataArray;
    UIBarButtonItem *back;
    
    NSString *strCountInventory;
    NSString *strCellInventoryID;
    
    NSString *strCountExpense;
    NSString *strCellExpenseID;
    
    BOOL SalesData;
    BOOL PaymentData;
    BOOL AtmData;
    BOOL CigaretteData;
    BOOL LotteryData;
    BOOL ExpenseData;
    BOOL InventoryData;
    
    NSMutableArray *arrDelete;
    
    
    NSMutableArray *arrTableData;
    
    
}
@property (nonatomic, strong) IBOutlet UIBarButtonItem *editButton;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *cancelButton;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *deleteButton;

@end

@implementation ViewController

@synthesize strId,strDate,strName;

-(void)Back
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    
    [self.navigationItem setTitle:@"Store Details"];
    
    back=[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"arrowsBack.png"]style:UIBarButtonItemStylePlain target:self action:@selector(Back)];
    
    self.navigationItem.leftBarButtonItem = back;
    
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    arrTableData=[[NSMutableArray alloc]initWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10", nil];
    tblViewMain.allowsMultipleSelectionDuringEditing = YES;
    
    // populate the data array with some example objects
    dataArray = [NSMutableArray new];
    
    NSString *itemFormatString = NSLocalizedString(@"Item %d", @"Format string for item");
    
    for (unsigned int itemNumber = 1; itemNumber <= 12; itemNumber++)
    {
        NSString *itemName = [NSString stringWithFormat:itemFormatString, itemNumber];
        [dataArray addObject:itemName];
    }
    
    // make our view consistent
    [self updateButtonsToMatchTableState];
    
    lblDate.text = @"28-02-2017";
    lblStore.text = @"Prem store";
}




- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 7;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0)
    {
        //Sales
        if (arrTableData.count == 0)
        {
            return 70;
        }
        else
        {
            return 40;
        }
    }
    else if (section == 1)
    {
        //Payment
        if (arrTableData.count == 0)
        {
            return 70;
        }
        else
        {
            return 40;
        }
    }
    else if (section == 2)
    {
        //Atm
        if (arrTableData.count == 0)
        {
            return 70;
        }
        else
        {
            return 40;
        }
    }
    else if (section == 3)
    {
        //Cigarette
        if (arrTableData.count == 0)
        {
            return 70;
        }
        else
        {
            return 40;
        }
    }
    else if (section == 4)
    {
        //Lottery
        if (arrTableData.count == 0)
        {
            return 70;
        }
        else
        {
            return 40;
        }
    }
    else if (section == 5)
    {
        //Expense
        if (arrTableData.count == 0)
        {
            return 70;
        }
        else
        {
            return 40;
        }
    }
    else if (section == 6)
    {
        //Inventory
        if (arrTableData.count == 0)
        {
            return 70;
        }
        else
        {
            return 40;
        }
    }
    return 0;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 0)
    {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,tableView.frame.size.width,40)];
        headerView.backgroundColor = [UIColor whiteColor];
        
        //Titlt Label
        UILabel *headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 10,100,20)];
        headerLabel.textAlignment = NSTextAlignmentLeft;
        headerLabel.text = @"Sales";
        headerLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:18];
        headerLabel.textColor = [UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1];
        [headerView addSubview:headerLabel];
        
        //Sales
        if (arrTableData.count == 0)
        {
            UILabel *BodyLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 40,200,20)];
            BodyLabel.textAlignment = NSTextAlignmentLeft;
            BodyLabel.text = @"No Data Availabel";
            BodyLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:15];
            BodyLabel.textColor = [UIColor darkGrayColor];
            [headerView addSubview:BodyLabel];
        }
        else
        {
            //Sales Edit
            UIButton *btnSalesEdit = [[UIButton alloc] initWithFrame:CGRectMake(headerView.frame.size.width-60.0, 10,20 ,20)];
            
            [btnSalesEdit setImage:[UIImage imageNamed:@"Edit.png"] forState:UIControlStateNormal];
            
            [btnSalesEdit addTarget:self action:@selector(ActionSalesEdit:) forControlEvents:UIControlEventTouchUpInside];
            
            [headerView addSubview:btnSalesEdit];
            
            //Sales Delete
            UIButton *btnSalesDelete = [[UIButton alloc] initWithFrame:CGRectMake(headerView.frame.size.width-30.0, 10,20 ,20)];
            
            [btnSalesDelete setImage:[UIImage imageNamed:@"Delete.png"] forState:UIControlStateNormal];
            
            [btnSalesDelete addTarget:self action:@selector(ActionSalesDelete:) forControlEvents:UIControlEventTouchUpInside];
            
            [headerView addSubview:btnSalesDelete];
        }
        
        return headerView;
    }
    else if (section == 1)
    {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,tableView.frame.size.width,40)];
        headerView.backgroundColor = [UIColor whiteColor];
        
        //Titlt Label
        UILabel *headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 10,100,20)];
        headerLabel.textAlignment = NSTextAlignmentLeft;
        headerLabel.text = @"Payment";
        headerLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:18];
        headerLabel.textColor = [UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1];
        [headerView addSubview:headerLabel];
        
        
        if (arrTableData.count == 0)
        {
            UILabel *BodyLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 40,200,20)];
            BodyLabel.textAlignment = NSTextAlignmentLeft;
            BodyLabel.text = @"No Data Availabel";
            BodyLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:15];
            BodyLabel.textColor = [UIColor darkGrayColor];
            [headerView addSubview:BodyLabel];
        }
        else
        {
            //Payment Edit
            UIButton *btnPaymentEdit = [[UIButton alloc] initWithFrame:CGRectMake(headerView.frame.size.width-60.0, 10,20 ,20)];
            
            [btnPaymentEdit setImage:[UIImage imageNamed:@"Edit.png"] forState:UIControlStateNormal];
            
            [btnPaymentEdit addTarget:self action:@selector(ActionPaymentEdit:) forControlEvents:UIControlEventTouchUpInside];
            
            [headerView addSubview:btnPaymentEdit];
            
            //Payment Delete
            UIButton *btnPaymentDelete = [[UIButton alloc] initWithFrame:CGRectMake(headerView.frame.size.width-30.0, 10,20 ,20)];
            
            [btnPaymentDelete setImage:[UIImage imageNamed:@"Delete.png"] forState:UIControlStateNormal];
            
            [btnPaymentDelete addTarget:self action:@selector(ActionPaymentDelete:) forControlEvents:UIControlEventTouchUpInside];
            
            [headerView addSubview:btnPaymentDelete];
        }
        
        return headerView;
        
    }
    else if (section == 2)
    {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,tableView.frame.size.width,40)];
        headerView.backgroundColor = [UIColor whiteColor];
        
        //Titlt Label
        UILabel *headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 10,100,20)];
        headerLabel.textAlignment = NSTextAlignmentLeft;
        headerLabel.text = @"ATM";
        headerLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:18];
        headerLabel.textColor = [UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1];
        [headerView addSubview:headerLabel];
        
        
        if (arrTableData.count == 0)
        {
            UILabel *BodyLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 40,200,20)];
            BodyLabel.textAlignment = NSTextAlignmentLeft;
            BodyLabel.text = @"No Data Availabel";
            BodyLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:15];
            BodyLabel.textColor = [UIColor darkGrayColor];
            [headerView addSubview:BodyLabel];
        }
        else
        {
            //ATM Edit
            UIButton *btnATMEdit = [[UIButton alloc] initWithFrame:CGRectMake(headerView.frame.size.width-60.0, 10,20 ,20)];
            
            [btnATMEdit setImage:[UIImage imageNamed:@"Edit.png"] forState:UIControlStateNormal];
            
            [btnATMEdit addTarget:self action:@selector(ActionATMEdit:) forControlEvents:UIControlEventTouchUpInside];
            
            [headerView addSubview:btnATMEdit];
            
            //ATM Delete
            UIButton *btnATMDelete = [[UIButton alloc] initWithFrame:CGRectMake(headerView.frame.size.width-30.0, 10,20 ,20)];
            
            [btnATMDelete setImage:[UIImage imageNamed:@"Delete.png"] forState:UIControlStateNormal];
            
            [btnATMDelete addTarget:self action:@selector(ActionATMDelete:) forControlEvents:UIControlEventTouchUpInside];
            
            [headerView addSubview:btnATMDelete];
        }
        
        return headerView;
        
    }
    else if (section == 3)
    {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,tableView.frame.size.width,40)];
        headerView.backgroundColor = [UIColor whiteColor];
        
        //Titlt Label
        UILabel *headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 10,100,20)];
        headerLabel.textAlignment = NSTextAlignmentLeft;
        headerLabel.text = @"Cigarette";
        headerLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:18];
        headerLabel.textColor = [UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1];
        [headerView addSubview:headerLabel];
        
        
        if (arrTableData.count == 0)
        {
            UILabel *BodyLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 40,200,20)];
            BodyLabel.textAlignment = NSTextAlignmentLeft;
            BodyLabel.text = @"No Data Availabel";
            BodyLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:15];
            BodyLabel.textColor = [UIColor darkGrayColor];
            [headerView addSubview:BodyLabel];
        }
        else
        {
            //Cigarette Edit
            UIButton *btnCigaretteEdit = [[UIButton alloc] initWithFrame:CGRectMake(headerView.frame.size.width-60.0, 10,20 ,20)];
            
            [btnCigaretteEdit setImage:[UIImage imageNamed:@"Edit.png"] forState:UIControlStateNormal];
            
            [btnCigaretteEdit addTarget:self action:@selector(ActionCigaretteEdit:) forControlEvents:UIControlEventTouchUpInside];
            
            [headerView addSubview:btnCigaretteEdit];
            
            //Cigarette Delete
            UIButton *btnCigaretteDelete = [[UIButton alloc] initWithFrame:CGRectMake(headerView.frame.size.width-30.0, 10,20 ,20)];
            
            [btnCigaretteDelete setImage:[UIImage imageNamed:@"Delete.png"] forState:UIControlStateNormal];
            
            [btnCigaretteDelete addTarget:self action:@selector(ActionCigaretteDelete:) forControlEvents:UIControlEventTouchUpInside];
            
            [headerView addSubview:btnCigaretteDelete];
        }
        
        return headerView;
        
    }
    else if (section == 4)
    {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,tableView.frame.size.width,40)];
        headerView.backgroundColor = [UIColor whiteColor];
        
        //Titlt Label
        UILabel *headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 10,100,20)];
        headerLabel.textAlignment = NSTextAlignmentLeft;
        headerLabel.text = @"Lottery";
        headerLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:18];
        headerLabel.textColor = [UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1];
        [headerView addSubview:headerLabel];
        
        if (arrTableData.count == 0)
        {
            UILabel *BodyLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 40,200,20)];
            BodyLabel.textAlignment = NSTextAlignmentLeft;
            BodyLabel.text = @"No Data Availabel";
            BodyLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:15];
            BodyLabel.textColor = [UIColor darkGrayColor];
            [headerView addSubview:BodyLabel];
        }
        else
        {
            //Lottery Edit
            UIButton *btnLotteryEdit = [[UIButton alloc] initWithFrame:CGRectMake(headerView.frame.size.width-60.0, 10,20 ,20)];
            
            [btnLotteryEdit setImage:[UIImage imageNamed:@"Edit.png"] forState:UIControlStateNormal];
            
            [btnLotteryEdit addTarget:self action:@selector(ActionLotteryEdit:) forControlEvents:UIControlEventTouchUpInside];
            
            [headerView addSubview:btnLotteryEdit];
            
            //Lottery Delete
            UIButton *btnLotteryDelete = [[UIButton alloc] initWithFrame:CGRectMake(headerView.frame.size.width-30.0, 10,20 ,20)];
            
            [btnLotteryDelete setImage:[UIImage imageNamed:@"Delete.png"] forState:UIControlStateNormal];
            
            [btnLotteryDelete addTarget:self action:@selector(ActionLotteryDelete:) forControlEvents:UIControlEventTouchUpInside];
            
            [headerView addSubview:btnLotteryDelete];
        }
        
        return headerView;
        
    }
    else if (section == 5)
    {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,tableView.frame.size.width,40)];
        headerView.backgroundColor = [UIColor whiteColor];
        
        //Titlt Label
        UILabel *headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 10,100,20)];
        headerLabel.textAlignment = NSTextAlignmentLeft;
        headerLabel.text = @"Expense";
        headerLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:18];
        headerLabel.textColor = [UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1];
        [headerView addSubview:headerLabel];
        
        if (arrTableData.count == 0)
        {
            UILabel *BodyLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 40,200,20)];
            BodyLabel.textAlignment = NSTextAlignmentLeft;
            BodyLabel.text = @"No Data Availabel";
            BodyLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:15];
            BodyLabel.textColor = [UIColor darkGrayColor];
            [headerView addSubview:BodyLabel];
        }
        else
        {
            
        }
        
        return headerView;
        
    }
    else if (section == 6)
    {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0,0,tableView.frame.size.width,40)];
        headerView.backgroundColor = [UIColor whiteColor];
        
        //Titlt Label
        UILabel *headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 10,100,20)];
        headerLabel.textAlignment = NSTextAlignmentLeft;
        headerLabel.text = @"Inventory";
        headerLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:18];
        headerLabel.textColor = [UIColor colorWithRed:0.0/255.0 green:122.0/255.0 blue:255.0/255.0 alpha:1];
        [headerView addSubview:headerLabel];
        
        if (arrTableData.count == 0)
        {
            UILabel *BodyLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 40,200,20)];
            BodyLabel.textAlignment = NSTextAlignmentLeft;
            BodyLabel.text = @"No Data Availabel";
            BodyLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:15];
            BodyLabel.textColor = [UIColor darkGrayColor];
            [headerView addSubview:BodyLabel];
        }
        else
        {
            
        }
        
        return headerView;
    }
    
    return 0;
    
}
-(IBAction)ActionSalesEdit:(id)sender
{
    NSLog(@"Edit Sales");
    
    
}
-(IBAction)ActionSalesDelete:(id)sender
{
    NSLog(@"Delete Sales");
}
-(IBAction)ActionPaymentEdit:(id)sender
{
        NSLog(@"Edit Payment");
}
-(IBAction)ActionPaymentDelete:(id)sender
{
    NSLog(@"Delete Payment");
}
-(IBAction)ActionATMEdit:(id)sender
{
    NSLog(@"Edit ATM");
}
-(IBAction)ActionATMDelete:(id)sender
{
    NSLog(@"Delete ATM");
    
}
-(IBAction)ActionCigaretteEdit:(id)sender
{
    NSLog(@"Edit Cigarette");
    
}
-(IBAction)ActionCigaretteDelete:(id)sender
{
    NSLog(@"Delete Cigarette");
    
}
-(IBAction)ActionLotteryEdit:(id)sender
{
    NSLog(@"Edit Lottery");
    
    }
-(IBAction)ActionLotteryDelete:(id)sender
{
    NSLog(@"Delete Lottery");
}
-(IBAction)ActionExpenseEdit:(UIButton*)btnEdit
{
    NSLog(@"Edit ID: %ld", (long)btnEdit.tag);
   }
-(IBAction)ActionExpenseDelete:(UIButton *)btnDelete
{
    NSLog(@"Delete ID: %ld",(long)btnDelete.tag);
    
}

-(IBAction)ActionInventoryDelete:(UIButton *)btnDelete
{
    NSLog(@"Delete ID: %ld",(long)btnDelete.tag);
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0)
    {
        return 216;
    }
    else if (indexPath.section == 1)
    {
        return 214;
    }
    else if (indexPath.section == 2)
    {
        return 97;
    }
    else if (indexPath.section == 3)
    {
        return 126;
    }
    else if (indexPath.section == 4)
    {
        return 184;
    }
    else if (indexPath.section == 5)
    {
        return 131;
    }
    else if (indexPath.section == 6)
    {
        return 185;
    }
    
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0)
    {
        return 1;
    }
    else if (section == 1)
    {
        return 1;
    }
    else if (section == 2)
    {
        return 1;
    }
    else if (section == 3)
    {
        return 1;
    }
    else if (section == 4)
    {
        return 1;
    }
    else if (section == 5)
    {
        return 1;
    }
    else if (section == 6)
    {
        return 1;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"tblcell";
    
    tblcell *cell = (tblcell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    cell.translatesAutoresizingMaskIntoConstraints = NO;
    
    if (indexPath.section == 0)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"sales" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
        cell.lblSalesInside.text =[NSString stringWithFormat:@"Sales: %@", [arrTableData objectAtIndex:0]];
        
        cell.lblSalesTax.text = [NSString stringWithFormat:@"Sales: %@", [arrTableData objectAtIndex:1]];
        
        cell.lblSalesGas.text = [NSString stringWithFormat:@"Sales: %@", [arrTableData objectAtIndex:2]];
        
        cell.lblSalesPhoneCard.text = [NSString stringWithFormat:@"Sales: %@", [arrTableData objectAtIndex:3]];
        
        cell.lblSalesInstant.text = [NSString stringWithFormat:@"Sales: %@", [arrTableData objectAtIndex:4]];
        
        cell.lblSalesLottery.text = [NSString stringWithFormat:@"Sales: %@", [arrTableData objectAtIndex:5]];
        
        cell.lblSalesTotalSales.text = [NSString stringWithFormat:@"Sales: %@", [arrTableData objectAtIndex:6]];
    }
    else if (indexPath.section == 1)
    {
        
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Payment" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
        cell.lblPaymentTotalPayment.text = [NSString stringWithFormat:@"Payment: %@", [arrTableData objectAtIndex:0]];
        
        cell.lblPaymentTotalCash.text = [NSString stringWithFormat:@"Payment: %@", [arrTableData objectAtIndex:1]];
        
        cell.lblPaymentTotalCredit.text = [NSString stringWithFormat:@"Payment: %@", [arrTableData objectAtIndex:2]];
        
        cell.lblPaymentTotalEBT.text = [NSString stringWithFormat:@"Payment: %@", [arrTableData objectAtIndex:3]];
        
        cell.lblPaymentLotteryOnlineCashOut.text = [NSString stringWithFormat:@"Payment: %@", [arrTableData objectAtIndex:4]];
        
        cell.lblPaymentLotteryInstantCashOut.text = [NSString stringWithFormat:@"Payment: %@", [arrTableData objectAtIndex:5]];
        
        cell.lblPaymentLotteryCashOut.text = [NSString stringWithFormat:@"Payment: %@", [arrTableData objectAtIndex:6]];
        
        cell.lblPaymentLotteryCashPayOut.text = [NSString stringWithFormat:@"Payment: %@", [arrTableData objectAtIndex:7]];
    }
    else if (indexPath.section == 2)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ATM" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
        cell.lblATMAvailableMoney.text = [NSString stringWithFormat:@"ATM: %@", [arrTableData objectAtIndex:0]];
        
        cell.lblATMAddMoney.text = [NSString stringWithFormat:@"ATM: %@", [arrTableData objectAtIndex:1]];
        
        cell.lblATMTotalMoney.text = [NSString stringWithFormat:@"ATM: %@", [arrTableData objectAtIndex:2]];
        
    }
    else if (indexPath.section == 3)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"cigeratte" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
        cell.lblCigaretteInventory.text = [NSString stringWithFormat:@"cigeratte: %@", [arrTableData objectAtIndex:0]];
        
        cell.lblCigaretteAddCigarette.text = [NSString stringWithFormat:@"cigeratte: %@", [arrTableData objectAtIndex:1]];
        
        cell.lblCigaretteSaleCigarette.text = [NSString stringWithFormat:@"cigeratte: %@", [arrTableData objectAtIndex:2]];
        
        cell.lblCigaretteAvailableStock.text = [NSString stringWithFormat:@"cigeratte: %@", [arrTableData objectAtIndex:3]];
        
    }
    else if (indexPath.section == 4)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Lottery" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
        cell.lblLotteryInventory.text = [NSString stringWithFormat:@"Lottery: %@", [arrTableData objectAtIndex:0]];
        
        cell.lblLotteryAddBook.text = [NSString stringWithFormat:@"Lottery: %@", [arrTableData objectAtIndex:1]];
        
        cell.lblLotteryActiveBook.text = [NSString stringWithFormat:@"Lottery: %@", [arrTableData objectAtIndex:2]];
        
        cell.lblLotteryTotal.text = [NSString stringWithFormat:@"Lottery: %@", [arrTableData objectAtIndex:3]];
        
        cell.lblLotteryWeeklyEFT.text = [NSString stringWithFormat:@"Lottery: %@", [arrTableData objectAtIndex:4]];
        
        cell.lblLotteryWeeklyCommission.text = [NSString stringWithFormat:@"Lottery: %@", [arrTableData objectAtIndex:5]];
        
    }
    else if (indexPath.section == 5)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Expence" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
        
        cell.lblExpenseType.text = [NSString stringWithFormat:@"Expence: %@", [arrTableData objectAtIndex:0]];
        
        cell.lblExpenseTitle.text = [NSString stringWithFormat:@"Expence: %@", [arrTableData objectAtIndex:1]];
        
        cell.lblExpenseAmount.text = [NSString stringWithFormat:@"Expence: %@", [arrTableData objectAtIndex:2]];
        
        cell.btnExpenseDelete.tag = indexPath.row;
        
        NSLog(@"Tag: %ld",(long)cell.btnExpenseDelete.tag);
        
        [cell.btnExpenseDelete addTarget:self action:@selector(ActionExpenseDelete:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.btnExpenseEdit.tag = indexPath.row;
        
        [cell.btnExpenseEdit addTarget:self action:@selector(ActionExpenseEdit:) forControlEvents:UIControlEventTouchUpInside];
        
        
    }
    else if (indexPath.section == 6)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Inventory" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
        cell.lblInventoryInvoiceNo.text = [NSString stringWithFormat:@"Inventory: %@", [arrTableData objectAtIndex:0]];
        
        cell.lblInventoryItem.text = [NSString stringWithFormat:@"Inventory: %@", [arrTableData objectAtIndex:1]];
        
        cell.lblInventoryVender.text = [NSString stringWithFormat:@"Inventory: %@", [arrTableData objectAtIndex:2]];
        
        cell.lblInventoryQuantity.text = [NSString stringWithFormat:@"Inventory: %@", [arrTableData objectAtIndex:3]];
        
        cell.lblInventoryPrice.text = [NSString stringWithFormat:@"Inventory: %@", [arrTableData objectAtIndex:4]];
        
        cell.btnInventoryDelete.tag = indexPath.row;
        
        NSLog(@"Tag: %ld",(long)cell.btnInventoryDelete.tag);
        
        [cell.btnInventoryDelete addTarget:self action:@selector(ActionInventoryDelete:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.btnInventoryEdit.tag = indexPath.row;
        
        NSLog(@"Tag: %ld",(long)cell.btnInventoryEdit.tag);
        
        [cell.btnInventoryEdit addTarget:self action:@selector(ActionInventoryEdit:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return cell;
}
- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Update the delete button's title based on how many items are selected.
    [self updateDeleteButtonTitle];
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Update the delete button's title based on how many items are selected.
    
    NSLog(@"indexPath: %ld",(long)indexPath.row);
    
    [self updateButtonsToMatchTableState];
    
}

- (IBAction)editAction:(id)sender
{
    [tblViewMain  setEditing:YES animated:YES];
    
    [self updateButtonsToMatchTableState];
}

- (IBAction)cancelAction:(id)sender
{
    [tblViewMain setEditing:NO animated:YES];
    
    [self updateButtonsToMatchTableState];
}


- (IBAction)deleteAction:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Are You Sure?" delegate:self cancelButtonTitle:@"Delete" otherButtonTitles:@"Cancel", nil];
    alert.tag = 007;
    [alert show];
}

- (void)updateButtonsToMatchTableState
{
    if (tblViewMain.editing)
    {
        // Show the option to cancel the edit.
        self.navigationItem.rightBarButtonItem = self.cancelButton;
        
        [self updateDeleteButtonTitle];
        
        // Show the delete button.
        self.navigationItem.leftBarButtonItem = self.deleteButton;
    }
    else
    {
        // Not in editing mode.
        //        self.navigationItem.leftBarButtonItem = back;
        
        self.navigationItem.leftBarButtonItem = back;
        
        // Show the edit button, but disable the edit button if there's nothing to edit.
        if (dataArray.count > 0)
        {
            self.editButton.enabled = YES;
        }
        else
        {
            self.editButton.enabled = NO;
        }
        self.navigationItem.rightBarButtonItem = self.editButton;
    }
}

- (void)updateDeleteButtonTitle
{
    // Update the delete button's title, based on how many items are selected
    NSArray *selectedRows = [tblViewMain indexPathsForSelectedRows];
    
    BOOL allItemsAreSelected = selectedRows.count == dataArray.count;
    BOOL noItemsAreSelected = selectedRows.count == 0;
    
    if (allItemsAreSelected || noItemsAreSelected)
    {
        NSLog(@"selectedRows: %@",selectedRows);
        
        self.deleteButton.enabled = NO;
    }
    else
    {
        
        NSLog(@"selectedRows: %@",selectedRows);
        
        self.deleteButton.enabled = YES;
        
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 1001)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete");
        }
    }
    else if (alertView.tag == 1000)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete1000");
        }
    }
    
    if (alertView.tag == 2001)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete");

        }
    }
    else if (alertView.tag == 2000)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete2000");
        }
    }
    
    if (alertView.tag == 3001)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete");
        }
    }
    else if (alertView.tag == 3000)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete3000");
        }
    }
    
    if (alertView.tag == 4001)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete");
        }
    }
    else if (alertView.tag == 4000)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete4000");
        }
    }
    
    if (alertView.tag == 5001)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete");
        }
    }
    else if (alertView.tag == 5000)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete5000");
        }
    }
    if (alertView.tag == 6001)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete");
        }
    }
    else if (alertView.tag == 6000)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete6000");
        }
    }
    if (alertView.tag == 7001)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete");
        }
    }
    else if (alertView.tag == 7000)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete7000");
        }
    }
    
    if (alertView.tag == 007)
    {
        if (buttonIndex == 0)
        {
            // Delete what the user selected.
            NSArray *selectedRows = [tblViewMain indexPathsForSelectedRows];
            BOOL deleteSpecificRows = selectedRows.count > 0;
            
            arrDelete = [[NSMutableArray alloc] init];
            
            if (deleteSpecificRows)
            {
                // Build an NSIndexSet of all the objects to delete, so they can all be removed at once.
                
                NSMutableIndexSet *indicesOfItemsToDelete = [NSMutableIndexSet new];
                
                for (NSIndexPath *selectionIndex in selectedRows)
                {
                    
                    NSLog(@"selectionIndex: %ld",(long)selectionIndex.row);
                    NSLog(@"%ld",(long)selectionIndex.section);
                    
                    NSString *strTemp = [NSString stringWithFormat:@"%ld-%ld",(long)selectionIndex.section,(long)selectionIndex.row];
                    
                    [arrDelete addObject:strTemp];
                    
                    [indicesOfItemsToDelete addIndex:selectionIndex.row];
                    
                    NSLog(@"arrDelete: %@",arrDelete);
                    
                }
                
                NSLog(@"arrDelete: %@",arrDelete);
                
                NSLog(@"indicesOfItemsToDelete: %@",indicesOfItemsToDelete);
                
         //       [self ApiDeleteMultiple];
                
            }
            
            // Exit editing mode after the deletion.
            [tblViewMain setEditing:NO animated:YES];
            
            [self updateButtonsToMatchTableState];
        }
    }
    else if (alertView.tag == 006)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"delete006");
        }
    }
}

@end
