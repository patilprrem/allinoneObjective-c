//
//  tblcell.h
//  AllInOneObjective-c
//
//  Created by GadgetZone on 28/02/17.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface tblcell : UITableViewCell
//Sales

@property (strong, nonatomic) IBOutlet UILabel *lblSalesInside;
@property (strong, nonatomic) IBOutlet UILabel *lblSalesTax;
@property (strong, nonatomic) IBOutlet UILabel *lblSalesGas;
@property (strong, nonatomic) IBOutlet UILabel *lblSalesPhoneCard;
@property (strong, nonatomic) IBOutlet UILabel *lblSalesInstant;
@property (strong, nonatomic) IBOutlet UILabel *lblSalesLottery;
@property (strong, nonatomic) IBOutlet UILabel *lblSalesTotalSales;

//Payment

@property (strong, nonatomic) IBOutlet UILabel *lblPaymentTotalCash;
@property (strong, nonatomic) IBOutlet UILabel *lblPaymentTotalCredit;
@property (strong, nonatomic) IBOutlet UILabel *lblPaymentTotalEBT;
@property (strong, nonatomic) IBOutlet UILabel *lblPaymentLotteryOnlineCashOut;
@property (strong, nonatomic) IBOutlet UILabel *lblPaymentLotteryInstantCashOut;

@property (strong, nonatomic) IBOutlet UILabel *lblPaymentLotteryCashOut;

@property (strong, nonatomic) IBOutlet UILabel *lblPaymentLotteryCashPayOut;

@property (strong, nonatomic) IBOutlet UILabel *lblPaymentTotalPayment;


//ATM

@property (strong, nonatomic) IBOutlet UILabel *lblATMAvailableMoney;
@property (strong, nonatomic) IBOutlet UILabel *lblATMAddMoney;
@property (strong, nonatomic) IBOutlet UILabel *lblATMTotalMoney;


//Cigarette

@property (strong, nonatomic) IBOutlet UILabel *lblCigaretteInventory;
@property (strong, nonatomic) IBOutlet UILabel *lblCigaretteAddCigarette;
@property (strong, nonatomic) IBOutlet UILabel *lblCigaretteSaleCigarette;
@property (strong, nonatomic) IBOutlet UILabel *lblCigaretteAvailableStock;


//Lottery


@property (strong, nonatomic) IBOutlet UILabel *lblLotteryInventory;
@property (strong, nonatomic) IBOutlet UILabel *lblLotteryAddBook;
@property (strong, nonatomic) IBOutlet UILabel *lblLotteryActiveBook;
@property (strong, nonatomic) IBOutlet UILabel *lblLotteryTotal;
@property (strong, nonatomic) IBOutlet UILabel *lblLotteryWeeklyEFT;
@property (strong, nonatomic) IBOutlet UILabel *lblLotteryWeeklyCommission;


//Expense

@property (strong, nonatomic) IBOutlet UILabel *lblExpenseType;
@property (strong, nonatomic) IBOutlet UILabel *lblExpenseTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblExpenseAmount;
@property (strong, nonatomic) IBOutlet UIButton *btnExpenseDelete;
@property (strong, nonatomic) IBOutlet UIButton *btnExpenseEdit;


//Inventory

@property (strong, nonatomic) IBOutlet UILabel *lblInventoryInvoiceNo;
@property (strong, nonatomic) IBOutlet UILabel *lblInventoryItem;
@property (strong, nonatomic) IBOutlet UILabel *lblInventoryVender;
@property (strong, nonatomic) IBOutlet UILabel *lblInventoryQuantity;
@property (strong, nonatomic) IBOutlet UILabel *lblInventoryPrice;
@property (strong, nonatomic) IBOutlet UIButton *btnInventoryDelete;
@property (strong, nonatomic) IBOutlet UIButton *btnInventoryEdit;

@end
