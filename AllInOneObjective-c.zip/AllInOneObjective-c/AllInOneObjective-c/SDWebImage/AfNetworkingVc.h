//
//  AfNetworkingVc.h
//  AllInOneObjective-c
//
//  Created by GadgetZone on 02/03/17.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "AFNetworking.h"
@interface AfNetworkingVc : UIViewController
{
    NSMutableDictionary *responseLogin;
    
    NSMutableDictionary *response;
    IBOutlet UILabel *lblTitle;
    
    
    IBOutlet UITextField *txtUserName;
    IBOutlet UITextField *txtPassword;
}
- (IBAction)ActionLogin:(id)sender;

@end
