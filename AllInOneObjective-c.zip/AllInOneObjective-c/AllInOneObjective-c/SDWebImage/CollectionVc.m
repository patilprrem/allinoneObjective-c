//
//  CollectionVc.m
//  AllInOneObjective-c
//
//  Created by GadgetZone on 02/03/17.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import "CollectionVc.h"

@interface CollectionVc ()
{
    NSMutableArray *arrImage;

}
@end

@implementation CollectionVc

- (void)viewDidLoad {
    [super viewDidLoad];
    arrImage=[[NSMutableArray alloc]initWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",nil];

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return arrImage.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString* Identifier=@"Collectioncell";
    
    UICollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:Identifier forIndexPath:indexPath];
    UIImageView *imgView=(UIImageView *)[cell viewWithTag:101];
    
    //create imageview
    imgView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width/2-15, 133)];
    imgView.image=[UIImage imageNamed:@"watch.jpg"];
    
    //create label
    UILabel *lbloffPrice=[[UILabel alloc]initWithFrame:CGRectMake(0, 141, self.view.frame.size.width/2-15, 28)];
    //    lbl.text=[arrText objectAtIndex:indexPath.row];
    lbloffPrice.text=@"Min 70% Off";
    lbloffPrice.textColor=[UIColor blueColor];
    lbloffPrice.textAlignment=NSTextAlignmentCenter;
    
    //create label
    UILabel *lblName=[[UILabel alloc]initWithFrame:CGRectMake(0, 177, self.view.frame.size.width/2-15, 28)];
    //    lbl.text=[arrText objectAtIndex:indexPath.row];
    lblName.text=@"Wrist Watch";
    lblName.textColor=[UIColor darkGrayColor];
    lblName.textAlignment=NSTextAlignmentCenter;
    
    //create label
    UILabel *lblStatus=[[UILabel alloc]initWithFrame:CGRectMake(0, 213, self.view.frame.size.width/2-15, 28)];
    //    lbl.text=[arrText objectAtIndex:indexPath.row];
    lblStatus.text=@"Explore Now!";
    lblStatus.textColor=[UIColor darkGrayColor];
    lblStatus.textAlignment=NSTextAlignmentCenter;
    
    //add containt in cell
    [cell addSubview:lblName];
    [cell addSubview:lbloffPrice];
    [cell addSubview:lblStatus];
    [cell addSubview:imgView];
    
    UIView *bgColorView = [[UIView alloc] init];
    bgColorView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [cell setSelectedBackgroundView:bgColorView];
    
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"indexPath :%ld",indexPath.row);
    
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGSize returnSize = CGSizeZero;
    float cellWidth = self.view.frame.size.width/2-15;
    // float cellhight=self.view.frame.size.width/2-37;
    float cellhight=250.0f;
    
    NSLog(@" cellhight :%f",cellhight);
    NSLog(@"cellWidth :%f",cellWidth);
    
    returnSize = CGSizeMake(cellWidth, cellhight);
    
    
    return returnSize;
    
}

@end
