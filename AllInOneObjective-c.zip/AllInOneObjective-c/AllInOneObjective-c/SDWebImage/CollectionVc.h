//
//  CollectionVc.h
//  AllInOneObjective-c
//
//  Created by GadgetZone on 02/03/17.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionVc : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate>
{
    IBOutlet UICollectionView *ViewCollection;
    
}
@end
