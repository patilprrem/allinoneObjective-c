//
//  AfNetworkingVc.m
//  AllInOneObjective-c
//
//  Created by GadgetZone on 02/03/17.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import "AfNetworkingVc.h"

@interface AfNetworkingVc ()

@end

@implementation AfNetworkingVc

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden=NO;
}

- (IBAction)ActionLogin:(id)sender
{
    NSString *emailRegEx = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
    
    if(txtUserName.text.length == 0)
    {
        [[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Please Enter Email" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
    }
    else if ([emailTest evaluateWithObject:txtUserName.text] == NO)
    {
        [[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Please Enter valid Email" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
    }
    else if (txtPassword.text.length == 0)
    {
        [[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Please Enter Password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
    }
    else
    {
        [self.view endEditing:YES];
        
        [self ApiLogin];
    }
}
-(void)ApiLogin
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDAnimationFade;
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    //if responce come in html form data use this line
    //=================================================
    
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    
    //==================================================
    
    //if responce come in json form data use this line
    
    //==================================================
    
//    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Accept"];
//    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    //===================================================
    
    
    [manager POST:[NSString stringWithFormat:@"http://www.airmedlabs.com/api_v5/home_page"] parameters:nil/*@{@"email":txtUserName.text,@"password":txtPassword.text}*/ progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject)
     {
         [MBProgressHUD hideHUDForView:self.view animated:YES];
         
         NSLog(@"%@",responseObject);
         
         responseLogin = (NSMutableDictionary *)responseObject;
         
         if ([[responseLogin valueForKey:@"status"] isEqualToString: @"1"])
         {
             
             
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Submit Successfully" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
             [alert show];

             
//             NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
//             
//             [defaults setObject:[responseLogin objectForKey:@"token"] forKey:@"token"];
//             
//             [defaults setObject:[[[responseLogin objectForKey:@"User"]objectAtIndex:0] valueForKey:@"id"] forKey:@"userid"];
//             
//             [defaults setObject:[[[responseLogin objectForKey:@"User"]objectAtIndex:0]valueForKey:@"role"] forKey:@"role"];
//             [defaults setObject:[[[responseLogin objectForKey:@"User"]objectAtIndex:0]valueForKey:@"email"] forKey:@"username"];
//             
//             if ([[defaults valueForKey:@"role"] isEqualToString:@"admin"])
//             {
//                 AdminHomeVC *push=[self.storyboard instantiateViewControllerWithIdentifier:@"AdminHomeVC"];
//                 [self.navigationController pushViewController:push animated:YES];
//             }
//             else if ([[defaults valueForKey:@"role"] isEqualToString:@"staff"])
//             {
//                 [defaults setObject:[[[responseLogin objectForKey:@"User"]objectAtIndex:0]valueForKey:@"store_id"] forKey:@"storeid"];
//                 
//                 DashboardVC *push=[self.storyboard instantiateViewControllerWithIdentifier:@"DashboardVC"];
//                 [self.navigationController pushViewController:push animated:YES];
//             }
         }
         else
         {
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:[responseLogin objectForKey:@"error_msg"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
             [alert show];
         }
         
     }
          failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error)
     {
         [MBProgressHUD hideHUDForView:self.view animated:YES];
         NSLog(@"%@",error.description);
         
         NSData *errorData = error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey];
         
         if (errorData)
         {
             NSDictionary *serializedData = [NSJSONSerialization JSONObjectWithData: errorData options:kNilOptions error:nil];
             NSLog(@"serializedData: %@",serializedData);
         }
         else
         {
             NSDictionary *noData = @{@"noData": @"No data!"};
             NSLog(@"noData: %@",noData);
         }
     }];
}


@end
