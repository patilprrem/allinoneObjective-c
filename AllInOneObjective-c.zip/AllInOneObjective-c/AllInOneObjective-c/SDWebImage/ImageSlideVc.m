//
//  ImageSlideVc.m
//  AllInOneObjective-c
//
//  Created by GadgetZone on 02/03/17.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import "ImageSlideVc.h"

@interface ImageSlideVc ()

@end

@implementation ImageSlideVc

- (void)viewDidLoad {
    [super viewDidLoad];
    [self apiServiceProviderImage];
    arrdata =[[NSMutableArray alloc]init];

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden=NO;
}
- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    imagePager.pageControl.currentPageIndicatorTintColor = [UIColor redColor];
    imagePager.pageControl.pageIndicatorTintColor = [UIColor blackColor];
    imagePager.slideshowTimeInterval = 5.5f;
    imagePager.slideshowShouldCallScrollToDelegate = YES;
}

#pragma mark - KIImagePager DataSource
- (NSArray *) arrayWithImages:(KIImagePager*)pager
{
    //    return @[
    //            @"https://raw.github.com/kimar/tapebooth/master/Screenshots/Screen1.png",
    //            @"https://raw.github.com/kimar/tapebooth/master/Screenshots/Screen2.png",
    //            @"https://raw.github.com/kimar/tapebooth/master/Screenshots/Screen3.png"
    //            ];
    return arrdata;
}

- (UIViewContentMode) contentModeForImage:(NSUInteger)image inPager:(KIImagePager *)pager
{
    return UIViewContentModeScaleAspectFill;
}
// show label to display image name

//- (NSString *) captionForImageAtIndex:(NSUInteger)index inPager:(KIImagePager *)pager
//{
//    return @[
//             @"First screenshot",
//             @"Another screenshot",
//             @"Last one! ;-)"
//             ][index];
//}

#pragma mark - KIImagePager Delegate
- (void) imagePager:(KIImagePager *)imagePager didScrollToIndex:(NSUInteger)index
{
    NSLog(@"%s %lu", __PRETTY_FUNCTION__, (unsigned long)index);
}

- (void) imagePager:(KIImagePager *)imagePager didSelectImageAtIndex:(NSUInteger)index
{
    NSLog(@"%s %lu", __PRETTY_FUNCTION__, (unsigned long)index);
}
-(void)apiServiceProviderImage
{
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.mode = MBProgressHUDAnimationFade;
    
        Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
        NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    
        if (networkStatus == NotReachable)
        {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please check your internet connection" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:nil];
            alert.tag=1001;
    
            [alert show];
        }
        else
        {
    
    [JSONHTTPClient postJSONFromURLWithString:[NSString stringWithFormat:@"http://www.airmedlabs.com/api_v5/home_page"]params:nil completion:^(id json, JSONModelError *err)
     {
         
         
         [MBProgressHUD hideHUDForView:self.view animated:YES];
         NSLog(@"%@",json);
         if (err)
         {
             NSLog(@"%@",err.description);
             UIAlertView *toast = [[UIAlertView alloc] initWithTitle:@"Alert"                                                                      message:@"Please Check your Internet Connection" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
             toast.tag=1002;
             
             [toast show];
         }
         else
         {
             responseRerviceProviderImage = (NSMutableDictionary *)json;
             NSLog(@"%lu",(unsigned long)responseRerviceProviderImage.count);
             
             
             
             if ([[responseRerviceProviderImage valueForKey:@"status"] integerValue] == 1)
             {
                 
                 NSLog(@"%@",responseRerviceProviderImage);
                 
                 for (int i=0; i< [[[[responseRerviceProviderImage valueForKey:@"data"]objectAtIndex:0]valueForKey:@"images"] count]; i++)
                 {
                     [arrdata addObject:[[[[[responseRerviceProviderImage valueForKey:@"data"]objectAtIndex:0]valueForKey:@"images"] objectAtIndex:i] valueForKey:@"pic"]];
                 }
                 
                 //arrdata=[[[responseRerviceProviderImage valueForKey:@"data"]objectAtIndex:0]valueForKey:@"images"];
                 
                 [imagePager reloadData];
                 NSLog(@"arrdata: %@",arrdata);
                 //[imgCollectionview reloadData];
                 
             }
             else
             {
                 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:[responseRerviceProviderImage valueForKey:@"error_msg"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                 [alert show];
             }
         }
     }];
    }
}

@end
