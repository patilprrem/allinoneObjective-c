//
//  ImageSlideVc.h
//  AllInOneObjective-c
//
//  Created by GadgetZone on 02/03/17.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KIImagePager.h"
#import "JSONHTTPClient.h"
#import "MBProgressHUD.h"
#import "Reachability.h"
@interface ImageSlideVc : UIViewController<KIImagePagerDataSource,KIImagePagerDelegate>
{
    IBOutlet KIImagePager *imagePager;
    NSMutableArray *arrdata;
    NSMutableDictionary *responseRerviceProviderImage;


}
@end
