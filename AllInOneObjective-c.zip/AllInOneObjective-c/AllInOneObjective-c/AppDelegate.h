//
//  AppDelegate.h
//  AllInOneObjective-c
//
//  Created by GadgetZone on 28/02/17.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IQKeyboardManager.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

