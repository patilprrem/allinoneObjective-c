//
//  main.m
//  AllInOneObjective-c
//
//  Created by GadgetZone on 28/02/17.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
